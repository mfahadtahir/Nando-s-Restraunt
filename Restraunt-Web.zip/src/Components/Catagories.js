Appeteasers             ->  Indian
Fino sides              ->  Fast Food
Peri-peri chicken       ->  Indian
Sharing platters        ->  Fast Food   / Indian
Desserts                ->  Dessert
Sides                   ->  Indian
Salads                  ->  Salad
Try someting new        ->  Indian
urgers, pitas, wraps    ->  Indian      / Burger